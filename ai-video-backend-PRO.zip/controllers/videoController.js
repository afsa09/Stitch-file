import Video from "../models/Video.js";
import { generateAIVideo } from "../utils/aiService.js";

export const generateVideo = async (req, res, next) => {
  try {
    const { prompt } = req.body;

    if (!prompt) {
      return res.status(400).json({ message: "Prompt is required" });
    }

    const videoUrl = await generateAIVideo(prompt);

    const video = await Video.create({
      user: req.user.id,
      prompt,
      videoUrl
    });

    res.json(video);
  } catch (error) {
    next(error);
  }
};

export const getUserVideos = async (req, res, next) => {
  try {
    const videos = await Video.find({ user: req.user.id }).sort({ createdAt: -1 });
    res.json(videos);
  } catch (error) {
    next(error);
  }
};