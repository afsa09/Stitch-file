import express from "express";
import { generateVideo, getUserVideos } from "../controllers/videoController.js";
import protect from "../middleware/authMiddleware.js";

const router = express.Router();

router.post("/generate", protect, generateVideo);
router.get("/myvideos", protect, getUserVideos);

export default router;